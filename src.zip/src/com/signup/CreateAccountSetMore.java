package com.signup;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.signup.NewTest;
import com.loginpagesetmore.setUpBrowser;

@Test
public class CreateAccountSetMore extends NewTest{
	
	
	
	SignUppage signPage;
	setUpBrowser setup = new setUpBrowser();
	
	@BeforeTest
	public void Browser()
	{
		setup.setUp();
		  signPage = PageFactory.initElements(setup.driver, SignUppage.class);

		signPage.singUpButton();
	}
	
	
	@Test(dataProvider = "getData")
	 public void f(String name, String email, String setpass) throws InterruptedException {
	  System.out.println(" you have provided your username as:: "+name);
	  	System.out.println("you have provided the email address as:: "+email);
	  System.out.println("your password is: "+setpass);
	  signPage = PageFactory.initElements(setup.driver, SignUppage.class);
	  
	  	
		signPage.enterName(name);
		signPage.enterEmail(email);
		signPage.enterPassword(setpass);
		signPage.okButton();
	Thread.sleep(4000);
	 
	 
//		
////		@Test(dataProvider="getData")
//		
//		
 }

	
//	public void createAccount()
//	{
//		setup.setUp();
//		signPage = PageFactory.initElements(setup.driver, SignUppage.class);
////		@Test(dataProvider="getData")
//		
//		signPage.singUpButton();
//		signPage.enterName("qwertyuioplkjhgfdsazxcvbnm,.");
//		signPage.enterEmail("sa@gmail.com");
//		signPage.enterPassword("sangeethaqwertyuiop");
//		signPage.okButton();
//	
//	
//		
//		
//		
//		
//	}
//	
//	
	
	
	
	

}
